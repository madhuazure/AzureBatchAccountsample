## MPIHelloWorld

This Visual Studio 2015 project is provided as a sample MPI application for use
with the [MultiInstanceTasks](../README.md) code sample. For more information
on building this project, see the [How to compile and run a simple MS-MPI
program][msmpi_howto] blog post.

[msmpi_howto]: http://blogs.technet.com/b/windowshpc/archive/2015/02/02/how-to-compile-and-run-a-simple-ms-mpi-program.aspx